function tourType(evt, tourCategory){
    //all variables
    var i, tabContent, tablinks;
    // hide all elements
    tabContent = document.getElementsByClassName("tabContent");
    for(i = 0; i < tabContent.length; i++){
       tabContent[i].style.display = "none";
    }
    // getting all tablinks and removing active class
    tablinks = document.getElementsByClassName("tourTabsBtn");
    for (i = 0; i < tablinks.length; i++){
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    // show tab with active class
    document.getElementById(tourCategory).style.display = "block";
    evt.currentTarget.className += " active";
}
//open tab by dedault
    document.getElementById("default").click();
