// refer to question 1 before development starts for scope document
// connect to this api https://api.magicthegathering.io/v1/cards
var searchCard = [];
fetch('https://api.magicthegathering.io/v1/cards')
    .then(result => result.json())
  .then((res) => {
    createCard(res);
    searchCard = res
  })
.catch(err => console.log(err))

    var details = document.getElementById('cards');
    function createCard(result){
    for (var i = 0; i < result.cards.length; i++){
    if (result.cards[i].imageUrl === undefined){
        result.cards[i].imageUrl = "https://via.placeholder.com/223x310";
    }       
        details.innerHTML += "<div class='col-sm-4'>" + "<div class='card-container'>" + "<h4>" + result.cards[i].name + "</h4>" + "<img src='" + result.cards[i].imageUrl + "' width='100%' >" + "<a href='card-specific.html?id="+ result.cards[i].id +"' class='btn btn-success'> View More </a>" + "</div>" + "</div>";
    }
      
}

function searchFilter(){
    
var searchField = document.getElementById("search");
    var filteredArray = searchCard.cards.filter(function(name) {
        return name.name === searchField.value;
    });
    if(filteredArray.length === 0){
        details.innerHTML = "<h2>Card not found</h2>";
    } else{
    for (var i = 0; i < filteredArray.length; i++){
    if (filteredArray[i].imageUrl === undefined){
        filteredArray[i].imageUrl = "https://via.placeholder.com/223x310";
    } 
        
        details.innerHTML += "<div class='col-sm-4'>" + "<div class='card-container'>" + "<h4>" + filteredArray[i].name + "</h4>" + "<img src='" + filteredArray[i].imageUrl + "' width='100%' >" + "<a href='card-specific.html?id="+ filteredArray[i].id +"' class='btn btn-success'> View More </a>" + "</div>" + "</div>";
        
    }
    } 
};
document.getElementById("searchButton").addEventListener("click", function(){
    details.innerHTML = "";
    searchFilter();
    
});

